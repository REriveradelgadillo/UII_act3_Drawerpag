package com.rivera0538

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
