# p13rutas-0538

A new Flutter project created with FlutLab - https://flutlab.io

## Getting Started

A few resources to get you started if this is your first Flutter project:

- https://flutter.dev/docs/get-started/codelab
- https://flutter.dev/docs/cookbook

For help getting started with Flutter, view our
https://flutter.dev/docs, which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Getting Started: FlutLab - Flutter Online IDE

- How to use FlutLab? Please, view our https://flutlab.io/docs
- Join the discussion and conversation on https://flutlab.io/residents

## resultado
![image](https://github.com/REriveradelgadillo/rutas-6J-0538/assets/143548741/4c67acc2-1500-4285-bcbf-9c44fdd216fc)
![image](https://github.com/REriveradelgadillo/rutas-6J-0538/assets/143548741/ccdee09e-6027-49a5-aef1-0fabdcb9c802)
![image](https://github.com/REriveradelgadillo/rutas-6J-0538/assets/143548741/9fdcf1c7-634d-4656-ab23-10619df47096)






